"""Redacción de la respuesta con plantillas y conectores fijos.

Nunca genera texto: une fragmentos literales del corpus con conectores y
citas declarados en la configuración del proyecto.
"""
from __future__ import annotations

from copy import deepcopy

from ipsis.consulta.etapas.base import _Etapa
from ipsis.consulta.variantes import elegir

# La apertura y cada fragmento van en su propio párrafo: el widget pinta los
# saltos de línea (``white-space: pre-wrap``) y un integrador puede partir por
# aquí. Un conector queda en el párrafo del fragmento que introduce.
SEPARADOR_PARRAFOS = "\n\n"


def _lista(valor) -> list[str]:
    """Plantillas de un dict anterior a los tonos pueden traer un texto suelto."""
    return [valor] if isinstance(valor, str) else list(valor)

# ==========================================================================
# REDACCION (sección 6.2 — plantillas y conectores fijos, nunca texto libre)
# ==========================================================================
def cargar_plantillas(paquete, dominio: dict | None = None, tono=None) -> dict:
    """Textos fijos del asistente: los del tono más los estructurales del idioma.

    Devuelve conectores, mensajes de abstención y textos conversacionales.
    ``tono`` es un ``PaqueteTono``; si falta, el tono por defecto con las
    sobrescrituras del proyecto del directorio actual. Con ``dominio``
    (``config/assistant.yaml``) sustituye ``{assistant_name}`` y
    ``{domain_description}`` en las respuestas conversacionales y aplica las
    contracciones del idioma («de el manual» -> «del manual»).
    """
    from pathlib import Path

    from ipsis.configuracion.personalidad import cargar_personalidad
    from ipsis.lenguaje.tonos import cargar_tono

    personalidad = cargar_personalidad(Path.cwd())
    if tono is None:
        tono = cargar_tono(paquete.codigo, personalidad.tono.activo, proyecto=Path.cwd(),
                           sobrescrituras=paquete.plantillas_legado)
    conectores = deepcopy(paquete.mensajes.conectores)  # secuencia y contraste_version
    for categoria in ("opening", "addition", "condition", "exception"):
        conectores[categoria] = tono.variantes(categoria)
    datos = {
        "tono": tono.tono,
        "variedad": personalidad.tono.variedad,
        "conectores": conectores,
        "abstencion": {
            "generico": tono.variantes("no_answer"),
            "premisa_no_encontrada": tono.variantes("premise_not_found"),
            "zona_gris_intro": tono.variantes("related_intro"),
            "foco_ausente": tono.variantes("missing_focus"),
        },
        "citas": {
            "breve": paquete.mensajes.cita_breve,
            "completa": paquete.mensajes.cita_completa,
            "sin_seccion": paquete.mensajes.sin_seccion,
        },
        "conversacional": {
            **paquete.conversacional.model_dump(mode="python"),
            "respuestas": {c: tono.variantes(c) for c in ("greeting", "thanks", "farewell", "capability")},
        },
    }
    if dominio is None:
        return datos
    variables = {
        "assistant_name": dominio.get("nombre_asistente", paquete.interfaz.get("default_assistant_name", "")),
        "domain_description": dominio.get("descripcion_dominio", paquete.interfaz.get("default_domain_description", "")),
    }

    def sustituir(texto: str) -> str:
        salida = texto.format(**variables)
        for forma, contraccion in paquete.contracciones.items():
            salida = salida.replace(forma, contraccion)
        return salida

    respuestas = datos["conversacional"].get("respuestas", {})
    for categoria, valor in respuestas.items():
        # Cada categoría puede declarar un texto suelto o varias variantes.
        respuestas[categoria] = sustituir(valor) if isinstance(valor, str) else [sustituir(t) for t in valor]
    return datos


def _cargar_plantillas() -> dict:
    """Textos del idioma activo (o español) para llamadas fuera de ``Motor``.

    Sustituye las variables con ``config/assistant.yaml`` del directorio
    actual, igual que el motor.
    """
    from ipsis.configuracion.carga import cargar_dominio
    from ipsis.lenguaje.entidades import idioma_activo
    from ipsis.lenguaje.paquete import cargar_paquete

    return cargar_plantillas(idioma_activo() or cargar_paquete("es"), cargar_dominio())


def _fragmentos_para_el_texto(fragmentos: list[dict], cfg: dict) -> list[dict]:
    """Decide QUE fragmentos entran en la prosa de la respuesta.

    Consume: los fragmentos recuperados (ya ordenados por pertinencia) y la
    seccion ``redaccion:`` de ``config/engine.yaml``. Produce: el
    subconjunto que se concatena en el texto.

    Antes se concatenaban los ``top_k`` completos, siempre. Con top_k=3 eso
    producia respuestas de tres bloques donde el tercero solia ser de otra
    seccion del documento y no venia al caso -- mas texto, menos precision.
    Ahora un fragmento posterior al primero entra solo si su score alcanza
    una fraccion del score del primero, y con un tope duro de cuantos
    caben.

    IMPORTANTE: esto acorta la PROSA, no esconde evidencia. El campo
    ``fragmentos`` de la respuesta HTTP sigue trayendo todos los
    recuperados, con su texto literal y sus offsets, que es lo que el widget
    despliega como citas. Nada de lo recuperado deja de estar disponible.

    Ambos valores son decisiones de diseno NO MEDIDAS (no hay golden set en
    el repositorio con el que medirlas); por eso son configurables y estan
    documentadas como tales en ``config/engine.yaml``."""
    if not fragmentos:
        return []
    tope = int(cfg.get("max_fragmentos_en_respuesta", 0) or 0)
    minimo_relativo = float(cfg.get("score_relativo_minimo", 0.0) or 0.0)
    primero = fragmentos[0]
    salida = [primero]
    referencia = float(primero.get("score") or 0.0)
    for frag in fragmentos[1:]:
        if tope and len(salida) >= tope:
            break
        if referencia > 0 and minimo_relativo > 0:
            if float(frag.get("score") or 0.0) < referencia * minimo_relativo:
                continue
        salida.append(frag)
    return salida


def _textos_de_cita(plantillas: dict) -> dict:
    """Formatos de la cita en el texto; los dicts armados a mano (pruebas) pueden no traerlos."""
    if "citas" in plantillas:
        return plantillas["citas"]
    from ipsis.lenguaje.paquete import cargar_paquete

    mensajes = cargar_paquete("es").mensajes
    return {"breve": mensajes.cita_breve, "completa": mensajes.cita_completa, "sin_seccion": mensajes.sin_seccion}


def _formatear_cita(frag: dict, estilo: str, citas: dict) -> str:
    """Cita que va DENTRO del texto de la respuesta.

    ``completa`` trae documento y ruta de seccion; ``breve``, solo el
    documento; ``ninguna`` no pone nada en el texto. En los tres casos la
    cita exacta -- documento, seccion y offsets -- sigue viajando en el
    campo estructurado ``fragmentos`` de la respuesta HTTP: esto decide
    cuanto se repite dentro de la prosa, no si se cita."""
    if estilo == "ninguna":
        return ""
    if estilo == "breve":
        return citas["breve"].format(documento=frag["doc_titulo"])
    seccion = " > ".join(frag.get("seccion_path") or []) or citas["sin_seccion"]
    return citas["completa"].format(documento=frag["doc_titulo"], seccion=seccion)


def texto_de_bloques(bloques: list[dict]) -> str:
    """El texto plano de la respuesta (``answer``): los bloques en párrafos."""
    partes = []
    for bloque in bloques:
        cuerpo = bloque["texto"]
        if bloque.get("cita"):
            cuerpo = f"{cuerpo} {bloque['cita']}."
        if bloque.get("conector"):
            cuerpo = f"{bloque['conector']} {cuerpo}"
        partes.append(cuerpo)
    return SEPARADOR_PARRAFOS.join(partes)


def _documento(frag: dict) -> str:
    return str(frag.get("doc_id") or frag.get("doc_titulo") or "")


def _bloques_fragmentos_con_citas(
    fragmentos: list[dict],
    con_apertura: bool = True,
    *,
    plantillas: dict | None = None,
    cfg_redaccion: dict | None = None,
) -> list[dict]:
    """Un bloque por párrafo: la apertura (``encabezado``) y cada fragmento
    (``pasaje``) con su texto LITERAL (nunca reescrito), su cita y, desde el
    segundo, un conector FIJO del tono -- la unica "redaccion" permitida.

    La CATEGORIA del conector la decide metadata determinista calculada en
    la ingesta (``tiene_excepcion``/``tiene_condicion``), nunca un modelo;
    la VARIANTE dentro de la categoria sale de ``ipsis.consulta.variantes``. Los
    conectores cierran en dos puntos a proposito: el texto que sigue es una
    cita literal que empieza donde el documento empiece, y un conector
    subordinante ("Siempre que,") producia frases rotas.

    Compartida por ``redactar`` (estado ``ok``) y ``redactar_zona_gris``
    (estado ``relacionado``)."""
    from ipsis.configuracion.carga import config_redaccion

    plantillas = plantillas or _cargar_plantillas()
    conectores = plantillas["conectores"]
    cfg = cfg_redaccion or config_redaccion()
    estilo_cita = str(cfg.get("cita_en_texto", "completa"))
    citas = _textos_de_cita(plantillas)

    elegidos = _fragmentos_para_el_texto(fragmentos, cfg)
    usadas: set[str] = set()
    bloques: list[dict] = []

    if con_apertura and cfg.get("incluir_apertura", True) and conectores.get("opening"):
        semilla = str(elegidos[0].get("chunk_id", "")) if elegidos else ""
        apertura = elegir("opening", list(conectores["opening"]), semilla)
        if apertura:
            bloques.append({"tipo": "encabezado", "texto": apertura})
            usadas.add(apertura)

    for i, frag in enumerate(elegidos):
        conector = None
        if i > 0:
            # Condición y excepción afirman que el pasaje matiza al primero: solo
            # tiene sentido dentro del mismo documento. De otro documento, se suma.
            mismo_documento = _documento(frag) == _documento(elegidos[0])
            if mismo_documento and frag.get("tiene_excepcion"):
                categoria = "exception"
            elif mismo_documento and frag.get("tiene_condicion"):
                categoria = "condition"
            else:
                categoria = "addition"
            opciones = list(conectores.get(categoria) or [])
            conector = elegir(categoria, opciones, str(frag.get("chunk_id", i)), usadas) or None
            if conector:
                usadas.add(conector)
        bloques.append({"tipo": "pasaje", "texto": frag["texto"].strip(), "conector": conector,
                        "cita": _formatear_cita(frag, estilo_cita, citas) or None,
                        "chunk_id": frag.get("chunk_id")})
    return bloques


def redactar_bloques(
    fragmentos: list[dict],
    *,
    plantillas: dict | None = None,
    cfg_redaccion: dict | None = None,
) -> list[dict]:
    """Respuesta normal (estado ``ok``) en bloques: apertura y fragmentos
    literales con citas y conectores fijos."""
    return _bloques_fragmentos_con_citas(fragmentos, plantillas=plantillas, cfg_redaccion=cfg_redaccion)


def redactar(fragmentos: list[dict], **kwargs) -> str:
    """Texto plano de :func:`redactar_bloques`."""
    return texto_de_bloques(redactar_bloques(fragmentos, **kwargs))


def redactar_zona_gris_bloques(
    fragmentos: list[dict],
    *,
    plantillas: dict | None = None,
    cfg_redaccion: dict | None = None,
    termino_ausente: str | None = None,
) -> list[dict]:
    """Estado propio ``"relacionado"`` (activo por defecto): cuando la pregunta
    pasa las dos capas de abstención pero el score denso es "intermedio"
    (ni claramente fuera de dominio ni un match fuerte), en vez de
    abstenerse se muestran los fragmentos más pertinentes enmarcados con un
    conector fijo que dice explícitamente que NO es una respuesta directa
    -- con citas literales y el encuadre explícito, mostrar texto
    relacionado no es una afirmación directa.
    Sigue siendo texto literal + cita; el único agregado es la frase de
    encabezado fija (``related_intro`` o ``missing_focus`` del tono).
    Lo decide ``cascada_v1`` (regla «relacionado»)."""
    plantillas = plantillas or _cargar_plantillas()
    # Si falta el término de foco, el mensaje lo nombra («No encontré información sobre «X»»).
    semilla = str(fragmentos[0].get("chunk_id", "")) if fragmentos else ""
    if termino_ausente:
        intro = elegir("missing_focus", _lista(plantillas["abstencion"]["foco_ausente"]), semilla)
        intro = intro.format(term=termino_ausente)
    else:
        intro = elegir("related_intro", _lista(plantillas["abstencion"]["zona_gris_intro"]), semilla)
    # Sin apertura: este estado ya trae su propio encabezado fijo, y apilar
    # los dos producia "No encontre una respuesta directa. Esto es lo que
    # dicen los documentos sobre el tema: Encontre esto en el documento:".
    return [{"tipo": "encabezado", "texto": intro},
            *_bloques_fragmentos_con_citas(fragmentos, con_apertura=False, plantillas=plantillas,
                                           cfg_redaccion=cfg_redaccion)]


def redactar_zona_gris(fragmentos: list[dict], **kwargs) -> str:
    """Texto plano de :func:`redactar_zona_gris_bloques`."""
    return texto_de_bloques(redactar_zona_gris_bloques(fragmentos, **kwargs))


def construir_mensaje_abstencion(
    motivo: str,
    entidad_texto: str | None = None,
    plantillas: dict | None = None,
) -> str:
    """Mensaje de abstención SIEMPRE listo para mostrar a un usuario final
    (nunca ``null`` en la respuesta HTTP: el servicio puede servir a un
    frontend externo -- plugin/widget de chat -- que necesita un string,
    no un estado vacío que interpretar). ``motivo`` en
    {"fuera_dominio", "premisa", "guardia", "sin_fragmentos"}; solo
    "premisa" usa ``entidad_texto`` (copiado LITERAL de la pregunta del
    usuario, nunca inventado)."""
    textos = (plantillas or _cargar_plantillas())["abstencion"]
    if motivo == "premisa" and entidad_texto:
        texto = elegir("premise_not_found", _lista(textos["premisa_no_encontrada"]), entidad_texto)
        return texto.format(entity=entidad_texto)
    return elegir("no_answer", _lista(textos["generico"]), motivo)


class EtapaRedaccion(_Etapa):
    """Arma el texto con plantillas: respuesta directa o pasajes relacionados."""

    nombre = "redaccion"

    def ejecutar(self, ctx) -> None:
        from ipsis.nucleo.esquemas import AssistantState

        m = self.motor
        if ctx.decision.resultado == "relacionado":
            termino = ctx.decision.entidad_texto if ctx.decision.motivo == "foco_ausente" else None
            ctx.bloques = redactar_zona_gris_bloques(ctx.payloads, plantillas=m.plantillas,
                                                     cfg_redaccion=m.configuracion_redaccion,
                                                     termino_ausente=termino)
            ctx.texto = texto_de_bloques(ctx.bloques)
            ctx.estado = AssistantState.RELACIONADO
            ctx.plan = "zona_gris"
            return
        ctx.bloques = redactar_bloques(ctx.payloads, plantillas=m.plantillas, cfg_redaccion=m.configuracion_redaccion)
        ctx.texto = texto_de_bloques(ctx.bloques)
        ctx.estado = AssistantState.RESPUESTA_DIRECTA
        ctx.plan = "extractivo"
